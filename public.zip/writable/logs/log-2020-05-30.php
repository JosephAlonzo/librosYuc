<?php defined('SYSTEMPATH') || exit('No direct script access allowed'); ?>

CRITICAL - 2020-05-30 01:01:55 --> Undefined variable: book
#0 C:\wamp64\www\proyectoLibreria\app\Views\pages\buybooks.php(26): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined varia...', 'C:\\wamp64\\www\\p...', 26, Array)
#1 C:\wamp64\www\proyectoLibreria\system\View\View.php(235): include('C:\\wamp64\\www\\p...')
#2 C:\wamp64\www\proyectoLibreria\system\Common.php(175): CodeIgniter\View\View->render('pages/buybooks', Array, NULL)
#3 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(128): view('pages/buybooks', Array)
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->seeBook()
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 01:22:08 --> Argument 3 passed to view() must be of the type array, null given, called in C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php on line 133
#0 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(133): view('pages/buybooks', Array, NULL)
#1 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->seeBook()
#2 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#3 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2020-05-30 01:22:19 --> Undefined variable: books
#0 C:\wamp64\www\proyectoLibreria\app\Views\pages\buybooks.php(4): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined varia...', 'C:\\wamp64\\www\\p...', 4, Array)
#1 C:\wamp64\www\proyectoLibreria\system\View\View.php(235): include('C:\\wamp64\\www\\p...')
#2 C:\wamp64\www\proyectoLibreria\system\Common.php(175): CodeIgniter\View\View->render('pages/buybooks', Array, NULL)
#3 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(133): view('pages/buybooks', Array)
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->seeBook()
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 01:23:09 --> Undefined variable: books
#0 C:\wamp64\www\proyectoLibreria\app\Views\pages\buybooks.php(4): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined varia...', 'C:\\wamp64\\www\\p...', 4, Array)
#1 C:\wamp64\www\proyectoLibreria\system\View\View.php(235): include('C:\\wamp64\\www\\p...')
#2 C:\wamp64\www\proyectoLibreria\system\Common.php(175): CodeIgniter\View\View->render('pages/buybooks', Array, NULL)
#3 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(133): view('pages/buybooks', Array)
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->seeBook()
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 01:23:35 --> Undefined variable: books
#0 C:\wamp64\www\proyectoLibreria\app\Views\pages\buybooks.php(4): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined varia...', 'C:\\wamp64\\www\\p...', 4, Array)
#1 C:\wamp64\www\proyectoLibreria\system\View\View.php(235): include('C:\\wamp64\\www\\p...')
#2 C:\wamp64\www\proyectoLibreria\system\Common.php(175): CodeIgniter\View\View->render('pages/buybooks', Array, NULL)
#3 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(133): view('pages/buybooks', Array)
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->seeBook()
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 01:23:44 --> Undefined variable: books
#0 C:\wamp64\www\proyectoLibreria\app\Views\pages\buybooks.php(4): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined varia...', 'C:\\wamp64\\www\\p...', 4, Array)
#1 C:\wamp64\www\proyectoLibreria\system\View\View.php(235): include('C:\\wamp64\\www\\p...')
#2 C:\wamp64\www\proyectoLibreria\system\Common.php(175): CodeIgniter\View\View->render('pages/buybooks', Array, NULL)
#3 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(133): view('pages/buybooks', Array)
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->seeBook()
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 01:24:11 --> Undefined variable: books
#0 C:\wamp64\www\proyectoLibreria\app\Views\pages\buybooks.php(4): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined varia...', 'C:\\wamp64\\www\\p...', 4, Array)
#1 C:\wamp64\www\proyectoLibreria\system\View\View.php(235): include('C:\\wamp64\\www\\p...')
#2 C:\wamp64\www\proyectoLibreria\system\Common.php(175): CodeIgniter\View\View->render('pages/buybooks', Array, NULL)
#3 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(133): view('pages/buybooks', Array)
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->seeBook()
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 01:24:45 --> Undefined variable: books
#0 C:\wamp64\www\proyectoLibreria\app\Views\pages\buybooks.php(4): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined varia...', 'C:\\wamp64\\www\\p...', 4, Array)
#1 C:\wamp64\www\proyectoLibreria\system\View\View.php(235): include('C:\\wamp64\\www\\p...')
#2 C:\wamp64\www\proyectoLibreria\system\Common.php(175): CodeIgniter\View\View->render('pages/buybooks', Array, NULL)
#3 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(130): view('pages/buybooks', Array)
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->seeBook()
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 01:26:22 --> Undefined variable: data
#0 C:\wamp64\www\proyectoLibreria\app\Views\pages\buybooks.php(1): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined varia...', 'C:\\wamp64\\www\\p...', 1, Array)
#1 C:\wamp64\www\proyectoLibreria\system\View\View.php(235): include('C:\\wamp64\\www\\p...')
#2 C:\wamp64\www\proyectoLibreria\system\Common.php(175): CodeIgniter\View\View->render('pages/buybooks', Array, NULL)
#3 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(130): view('pages/buybooks', Array, Array)
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->seeBook()
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 01:26:39 --> Undefined variable: data
#0 C:\wamp64\www\proyectoLibreria\app\Views\pages\buybooks.php(1): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined varia...', 'C:\\wamp64\\www\\p...', 1, Array)
#1 C:\wamp64\www\proyectoLibreria\system\View\View.php(235): include('C:\\wamp64\\www\\p...')
#2 C:\wamp64\www\proyectoLibreria\system\Common.php(175): CodeIgniter\View\View->render('pages/buybooks', Array, NULL)
#3 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(130): view('pages/buybooks', Array, Array)
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->seeBook()
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 01:26:50 --> Undefined variable: data
#0 C:\wamp64\www\proyectoLibreria\app\Views\pages\buybooks.php(1): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined varia...', 'C:\\wamp64\\www\\p...', 1, Array)
#1 C:\wamp64\www\proyectoLibreria\system\View\View.php(235): include('C:\\wamp64\\www\\p...')
#2 C:\wamp64\www\proyectoLibreria\system\Common.php(175): CodeIgniter\View\View->render('pages/buybooks', Array, NULL)
#3 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(130): view('pages/buybooks', Array)
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->seeBook()
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 01:27:28 --> Undefined variable: data
#0 C:\wamp64\www\proyectoLibreria\app\Views\pages\buybooks.php(1): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined varia...', 'C:\\wamp64\\www\\p...', 1, Array)
#1 C:\wamp64\www\proyectoLibreria\system\View\View.php(235): include('C:\\wamp64\\www\\p...')
#2 C:\wamp64\www\proyectoLibreria\system\Common.php(175): CodeIgniter\View\View->render('pages/buybooks', Array, NULL)
#3 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(130): view('pages/buybooks', Array, Array)
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->seeBook()
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 01:28:38 --> syntax error, unexpected ';'
#0 C:\wamp64\www\proyectoLibreria\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\wamp64\\www\\p...')
#1 C:\wamp64\www\proyectoLibreria\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(792): class_exists('\\App\\Controller...', true)
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 01:28:48 --> Undefined variable: data
#0 C:\wamp64\www\proyectoLibreria\app\Views\pages\buybooks.php(1): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined varia...', 'C:\\wamp64\\www\\p...', 1, Array)
#1 C:\wamp64\www\proyectoLibreria\system\View\View.php(235): include('C:\\wamp64\\www\\p...')
#2 C:\wamp64\www\proyectoLibreria\system\Common.php(175): CodeIgniter\View\View->render('pages/buybooks', Array, NULL)
#3 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(130): view('pages/buybooks', Array, Array)
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->seeBook()
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 01:29:07 --> Undefined variable: nowreading
#0 C:\wamp64\www\proyectoLibreria\app\Views\pages\buybooks.php(1): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined varia...', 'C:\\wamp64\\www\\p...', 1, Array)
#1 C:\wamp64\www\proyectoLibreria\system\View\View.php(235): include('C:\\wamp64\\www\\p...')
#2 C:\wamp64\www\proyectoLibreria\system\Common.php(175): CodeIgniter\View\View->render('pages/buybooks', Array, NULL)
#3 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(130): view('pages/buybooks', Array, Array)
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->seeBook()
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 01:30:19 --> Undefined variable: nowreading
#0 C:\wamp64\www\proyectoLibreria\app\Views\pages\buybooks.php(1): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined varia...', 'C:\\wamp64\\www\\p...', 1, Array)
#1 C:\wamp64\www\proyectoLibreria\system\View\View.php(235): include('C:\\wamp64\\www\\p...')
#2 C:\wamp64\www\proyectoLibreria\system\Common.php(175): CodeIgniter\View\View->render('pages/buybooks', Array, NULL)
#3 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(128): view('pages/buybooks', Array, Array)
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->seeBook()
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 01:31:00 --> Undefined variable: nowreading
#0 C:\wamp64\www\proyectoLibreria\app\Views\pages\buybooks.php(1): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined varia...', 'C:\\wamp64\\www\\p...', 1, Array)
#1 C:\wamp64\www\proyectoLibreria\system\View\View.php(235): include('C:\\wamp64\\www\\p...')
#2 C:\wamp64\www\proyectoLibreria\system\Common.php(175): CodeIgniter\View\View->render('pages/buybooks', Array, NULL)
#3 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(128): view('pages/buybooks', Array, Array)
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->seeBook()
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 01:45:53 --> Unknown column 'nowreading.deleted' in 'where clause'
#0 C:\wamp64\www\proyectoLibreria\system\Database\MySQLi\Connection.php(329): mysqli->query('SELECT *\nFROM `...')
#1 C:\wamp64\www\proyectoLibreria\system\Database\BaseConnection.php(709): CodeIgniter\Database\MySQLi\Connection->execute('SELECT *\nFROM `...')
#2 C:\wamp64\www\proyectoLibreria\system\Database\BaseConnection.php(637): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT *\nFROM `...')
#3 C:\wamp64\www\proyectoLibreria\system\Database\BaseBuilder.php(1476): CodeIgniter\Database\BaseConnection->query('SELECT *\nFROM `...', Array, false)
#4 C:\wamp64\www\proyectoLibreria\system\Model.php(377): CodeIgniter\Database\BaseBuilder->get()
#5 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(122): CodeIgniter\Model->find()
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->seeBook()
#7 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#8 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#9 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#10 {main}
CRITICAL - 2020-05-30 01:52:37 --> Unknown column 'wishlist.deleted' in 'where clause'
#0 C:\wamp64\www\proyectoLibreria\system\Database\MySQLi\Connection.php(329): mysqli->query('SELECT *\nFROM `...')
#1 C:\wamp64\www\proyectoLibreria\system\Database\BaseConnection.php(709): CodeIgniter\Database\MySQLi\Connection->execute('SELECT *\nFROM `...')
#2 C:\wamp64\www\proyectoLibreria\system\Database\BaseConnection.php(637): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT *\nFROM `...')
#3 C:\wamp64\www\proyectoLibreria\system\Database\BaseBuilder.php(1476): CodeIgniter\Database\BaseConnection->query('SELECT *\nFROM `...', Array, false)
#4 C:\wamp64\www\proyectoLibreria\system\Model.php(377): CodeIgniter\Database\BaseBuilder->get()
#5 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(126): CodeIgniter\Model->find()
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->seeBook()
#7 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#8 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#9 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#10 {main}
CRITICAL - 2020-05-30 02:04:27 --> syntax error, unexpected 'return' (T_RETURN)
#0 C:\wamp64\www\proyectoLibreria\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\wamp64\\www\\p...')
#1 C:\wamp64\www\proyectoLibreria\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(792): class_exists('\\App\\Controller...', true)
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 02:04:54 --> Undefined index: id
#0 C:\wamp64\www\proyectoLibreria\app\Views\pages\buybooks.php(27): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined index...', 'C:\\wamp64\\www\\p...', 27, Array)
#1 C:\wamp64\www\proyectoLibreria\system\View\View.php(235): include('C:\\wamp64\\www\\p...')
#2 C:\wamp64\www\proyectoLibreria\system\Common.php(175): CodeIgniter\View\View->render('pages/buybooks', Array, NULL)
#3 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(138): view('pages/buybooks', Array)
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->seeBook()
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 02:05:38 --> Undefined index: id
#0 C:\wamp64\www\proyectoLibreria\app\Views\pages\buybooks.php(28): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined index...', 'C:\\wamp64\\www\\p...', 28, Array)
#1 C:\wamp64\www\proyectoLibreria\system\View\View.php(235): include('C:\\wamp64\\www\\p...')
#2 C:\wamp64\www\proyectoLibreria\system\Common.php(175): CodeIgniter\View\View->render('pages/buybooks', Array, NULL)
#3 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(138): view('pages/buybooks', Array)
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->seeBook()
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 02:06:07 --> syntax error, unexpected '$users' (T_VARIABLE)
#0 C:\wamp64\www\proyectoLibreria\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\wamp64\\www\\p...')
#1 C:\wamp64\www\proyectoLibreria\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(792): class_exists('\\App\\Controller...', true)
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 02:06:15 --> Undefined index: id
#0 C:\wamp64\www\proyectoLibreria\app\Views\pages\buybooks.php(28): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined index...', 'C:\\wamp64\\www\\p...', 28, Array)
#1 C:\wamp64\www\proyectoLibreria\system\View\View.php(235): include('C:\\wamp64\\www\\p...')
#2 C:\wamp64\www\proyectoLibreria\system\Common.php(175): CodeIgniter\View\View->render('pages/buybooks', Array, NULL)
#3 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(139): view('pages/buybooks', Array)
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->seeBook()
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 02:06:47 --> Undefined index: id
#0 C:\wamp64\www\proyectoLibreria\app\Views\pages\buybooks.php(28): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined index...', 'C:\\wamp64\\www\\p...', 28, Array)
#1 C:\wamp64\www\proyectoLibreria\system\View\View.php(235): include('C:\\wamp64\\www\\p...')
#2 C:\wamp64\www\proyectoLibreria\system\Common.php(175): CodeIgniter\View\View->render('pages/buybooks', Array, NULL)
#3 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(139): view('pages/buybooks', Array)
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->seeBook()
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 02:07:15 --> Undefined index: id
#0 C:\wamp64\www\proyectoLibreria\app\Views\pages\buybooks.php(28): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined index...', 'C:\\wamp64\\www\\p...', 28, Array)
#1 C:\wamp64\www\proyectoLibreria\system\View\View.php(235): include('C:\\wamp64\\www\\p...')
#2 C:\wamp64\www\proyectoLibreria\system\Common.php(175): CodeIgniter\View\View->render('pages/buybooks', Array, NULL)
#3 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(139): view('pages/buybooks', Array)
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->seeBook()
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 02:07:54 --> Undefined offset: 0
#0 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(135): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined offse...', 'C:\\wamp64\\www\\p...', 135, Array)
#1 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->seeBook()
#2 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#3 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2020-05-30 02:08:41 --> Deletes are not allowed unless they contain a "where" or "like" clause.
#0 C:\wamp64\www\proyectoLibreria\system\Model.php(922): CodeIgniter\Database\BaseBuilder->delete()
#1 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(178): CodeIgniter\Model->delete(NULL)
#2 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->deleteToNowReading()
#3 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2020-05-30 02:10:41 --> Undefined variable: idBook
#0 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(179): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined varia...', 'C:\\wamp64\\www\\p...', 179, Array)
#1 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->deleteToNowReading()
#2 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#3 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2020-05-30 02:15:38 --> Deletes are not allowed unless they contain a "where" or "like" clause.
#0 C:\wamp64\www\proyectoLibreria\system\Model.php(922): CodeIgniter\Database\BaseBuilder->delete()
#1 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(185): CodeIgniter\Model->delete('')
#2 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->deleteToWishlist()
#3 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2020-05-30 02:16:27 --> Deletes are not allowed unless they contain a "where" or "like" clause.
#0 C:\wamp64\www\proyectoLibreria\system\Model.php(922): CodeIgniter\Database\BaseBuilder->delete()
#1 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(191): CodeIgniter\Model->delete('')
#2 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->deleteToWishlist()
#3 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2020-05-30 02:17:12 --> Deletes are not allowed unless they contain a "where" or "like" clause.
#0 C:\wamp64\www\proyectoLibreria\system\Model.php(922): CodeIgniter\Database\BaseBuilder->delete()
#1 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(191): CodeIgniter\Model->delete('')
#2 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->deleteToWishlist()
#3 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2020-05-30 02:22:39 --> Deletes are not allowed unless they contain a "where" or "like" clause.
#0 C:\wamp64\www\proyectoLibreria\system\Model.php(922): CodeIgniter\Database\BaseBuilder->delete()
#1 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(191): CodeIgniter\Model->delete(NULL)
#2 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->deleteToWishlist()
#3 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2020-05-30 02:23:42 --> Deletes are not allowed unless they contain a "where" or "like" clause.
#0 C:\wamp64\www\proyectoLibreria\system\Model.php(922): CodeIgniter\Database\BaseBuilder->delete()
#1 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(191): CodeIgniter\Model->delete(NULL)
#2 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->deleteToWishlist()
#3 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2020-05-30 02:52:53 --> syntax error, unexpected ';', expecting ')'
#0 C:\wamp64\www\proyectoLibreria\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\wamp64\\www\\p...')
#1 C:\wamp64\www\proyectoLibreria\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(792): class_exists('\\App\\Controller...', true)
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 02:53:05 --> Undefined property: App\Controllers\BookController::$nowReadingModel
#0 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(55): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined prope...', 'C:\\wamp64\\www\\p...', 55, Array)
#1 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->nowReading()
#2 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#3 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2020-05-30 02:53:24 --> Undefined property: App\Controllers\BookController::$nowReadingModel
#0 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(55): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined prope...', 'C:\\wamp64\\www\\p...', 55, Array)
#1 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->nowReading()
#2 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#3 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2020-05-30 02:54:41 --> syntax error, unexpected ';', expecting ')'
#0 C:\wamp64\www\proyectoLibreria\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\wamp64\\www\\p...')
#1 C:\wamp64\www\proyectoLibreria\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(792): class_exists('\\App\\Controller...', true)
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 02:54:50 --> Undefined property: App\Controllers\BookController::$nowReadingModel
#0 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(55): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined prope...', 'C:\\wamp64\\www\\p...', 55, Array)
#1 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->nowReading()
#2 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#3 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2020-05-30 02:56:24 --> Undefined property: App\Controllers\BookController::$nowReadingModel
#0 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(55): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined prope...', 'C:\\wamp64\\www\\p...', 55, Array)
#1 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->nowReading()
#2 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#3 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2020-05-30 02:56:39 --> Undefined property: App\Controllers\BookController::$nowReadingModel
#0 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(55): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined prope...', 'C:\\wamp64\\www\\p...', 55, Array)
#1 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->nowReading()
#2 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#3 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2020-05-30 02:56:40 --> Undefined property: App\Controllers\BookController::$nowReadingModel
#0 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(55): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined prope...', 'C:\\wamp64\\www\\p...', 55, Array)
#1 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->nowReading()
#2 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#3 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2020-05-30 02:56:49 --> Undefined property: App\Controllers\BookController::$nowReadingModel
#0 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(55): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined prope...', 'C:\\wamp64\\www\\p...', 55, Array)
#1 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->nowReading()
#2 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#3 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2020-05-30 02:57:33 --> Undefined property: App\Controllers\BookController::$nowReadingModel
#0 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(55): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined prope...', 'C:\\wamp64\\www\\p...', 55, Array)
#1 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->nowReading()
#2 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#3 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2020-05-30 02:58:12 --> syntax error, unexpected '$structure' (T_VARIABLE)
#0 C:\wamp64\www\proyectoLibreria\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\wamp64\\www\\p...')
#1 C:\wamp64\www\proyectoLibreria\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(792): class_exists('\\App\\Controller...', true)
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 02:58:45 --> Argument 1 passed to CodeIgniter\Database\BaseBuilder::join() must be of the type string, object given, called in C:\wamp64\www\proyectoLibreria\system\Model.php on line 1640
#0 C:\wamp64\www\proyectoLibreria\system\Model.php(1640): CodeIgniter\Database\BaseBuilder->join(Object(App\Models\BookModel))
#1 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(56): CodeIgniter\Model->__call('join', Array)
#2 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->nowReading()
#3 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2020-05-30 03:46:25 --> Undefined variable: request
#0 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(146): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined varia...', 'C:\\wamp64\\www\\p...', 146, Array)
#1 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(132): App\Controllers\BookController->addHistory('2', '1')
#2 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->seeBook()
#3 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2020-05-30 03:56:49 --> syntax error, unexpected '=', expecting ')'
#0 C:\wamp64\www\proyectoLibreria\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\wamp64\\www\\p...')
#1 C:\wamp64\www\proyectoLibreria\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(792): class_exists('\\App\\Controller...', true)
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 03:59:19 --> syntax error, unexpected ''id_user'' (T_CONSTANT_ENCAPSED_STRING), expecting ')'
#0 C:\wamp64\www\proyectoLibreria\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\wamp64\\www\\p...')
#1 C:\wamp64\www\proyectoLibreria\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(792): class_exists('\\App\\Controller...', true)
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 03:59:22 --> syntax error, unexpected ''id_user'' (T_CONSTANT_ENCAPSED_STRING), expecting ')'
#0 C:\wamp64\www\proyectoLibreria\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\wamp64\\www\\p...')
#1 C:\wamp64\www\proyectoLibreria\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(792): class_exists('\\App\\Controller...', true)
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 03:59:25 --> syntax error, unexpected ''id_user'' (T_CONSTANT_ENCAPSED_STRING), expecting ')'
#0 C:\wamp64\www\proyectoLibreria\system\Autoloader\Autoloader.php(295): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\wamp64\\www\\p...')
#1 C:\wamp64\www\proyectoLibreria\system\Autoloader\Autoloader.php(257): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(792): class_exists('\\App\\Controller...', true)
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(325): CodeIgniter\CodeIgniter->startController()
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 04:08:58 --> Unknown column 'nowreading.id_book' in 'on clause'
#0 C:\wamp64\www\proyectoLibreria\system\Database\MySQLi\Connection.php(329): mysqli->query('SELECT *\nFROM `...')
#1 C:\wamp64\www\proyectoLibreria\system\Database\BaseConnection.php(709): CodeIgniter\Database\MySQLi\Connection->execute('SELECT *\nFROM `...')
#2 C:\wamp64\www\proyectoLibreria\system\Database\BaseConnection.php(637): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT *\nFROM `...')
#3 C:\wamp64\www\proyectoLibreria\system\Database\BaseBuilder.php(1476): CodeIgniter\Database\BaseConnection->query('SELECT *\nFROM `...', Array, false)
#4 C:\wamp64\www\proyectoLibreria\system\Model.php(377): CodeIgniter\Database\BaseBuilder->get()
#5 C:\wamp64\www\proyectoLibreria\app\Controllers\HistoryController.php(24): CodeIgniter\Model->find()
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\HistoryController->history()
#7 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\HistoryController))
#8 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#9 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#10 {main}
CRITICAL - 2020-05-30 04:29:27 --> Cannot redeclare App\Controllers\BookController::mostRead()
#0 [internal function]: CodeIgniter\Debug\Exceptions->shutdownHandler()
#1 {main}
CRITICAL - 2020-05-30 04:30:01 --> Call to a member function orderBy() on null
#0 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->mostRead()
#1 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#2 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2020-05-30 04:30:30 --> Call to a member function orderBy() on null
#0 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->mostRead()
#1 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#2 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#4 {main}
CRITICAL - 2020-05-30 04:31:38 --> Unknown column 'id_book' in 'group statement'
#0 C:\wamp64\www\proyectoLibreria\system\Database\MySQLi\Connection.php(329): mysqli->query('SELECT *\nFROM `...')
#1 C:\wamp64\www\proyectoLibreria\system\Database\BaseConnection.php(709): CodeIgniter\Database\MySQLi\Connection->execute('SELECT *\nFROM `...')
#2 C:\wamp64\www\proyectoLibreria\system\Database\BaseConnection.php(637): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT *\nFROM `...')
#3 C:\wamp64\www\proyectoLibreria\system\Database\BaseBuilder.php(1476): CodeIgniter\Database\BaseConnection->query('SELECT *\nFROM `...', Array, false)
#4 C:\wamp64\www\proyectoLibreria\system\Model.php(434): CodeIgniter\Database\BaseBuilder->get()
#5 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(94): CodeIgniter\Model->findAll(1, 10)
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->mostRead()
#7 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#8 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#9 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#10 {main}
CRITICAL - 2020-05-30 04:44:42 --> Undefined variable: users
#0 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(108): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined varia...', 'C:\\wamp64\\www\\p...', 108, Array)
#1 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->bestOfList()
#2 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#3 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2020-05-30 04:45:46 --> Unknown column 'id_book' in 'group statement'
#0 C:\wamp64\www\proyectoLibreria\system\Database\MySQLi\Connection.php(329): mysqli->query('SELECT *\nFROM `...')
#1 C:\wamp64\www\proyectoLibreria\system\Database\BaseConnection.php(709): CodeIgniter\Database\MySQLi\Connection->execute('SELECT *\nFROM `...')
#2 C:\wamp64\www\proyectoLibreria\system\Database\BaseConnection.php(637): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT *\nFROM `...')
#3 C:\wamp64\www\proyectoLibreria\system\Database\BaseBuilder.php(1476): CodeIgniter\Database\BaseConnection->query('SELECT *\nFROM `...', Array, false)
#4 C:\wamp64\www\proyectoLibreria\system\Model.php(434): CodeIgniter\Database\BaseBuilder->get()
#5 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(94): CodeIgniter\Model->findAll(1, 10)
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->mostRead()
#7 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#8 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#9 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#10 {main}
CRITICAL - 2020-05-30 11:24:18 --> Undefined index: foto
#0 C:\wamp64\www\proyectoLibreria\app\Views\includes\header.php(22): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined index...', 'C:\\wamp64\\www\\p...', 22, Array)
#1 C:\wamp64\www\proyectoLibreria\system\View\View.php(235): include('C:\\wamp64\\www\\p...')
#2 C:\wamp64\www\proyectoLibreria\system\Common.php(175): CodeIgniter\View\View->render('includes/header', Array, NULL)
#3 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(37): view('includes/header', Array)
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->index()
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 11:27:25 --> Undefined index: foto
#0 C:\wamp64\www\proyectoLibreria\app\Views\includes\header.php(23): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined index...', 'C:\\wamp64\\www\\p...', 23, Array)
#1 C:\wamp64\www\proyectoLibreria\system\View\View.php(235): include('C:\\wamp64\\www\\p...')
#2 C:\wamp64\www\proyectoLibreria\system\Common.php(175): CodeIgniter\View\View->render('includes/header', Array, NULL)
#3 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(37): view('includes/header', Array)
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->index()
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 11:31:29 --> Undefined index: foto
#0 C:\wamp64\www\proyectoLibreria\app\Views\includes\header.php(22): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined index...', 'C:\\wamp64\\www\\p...', 22, Array)
#1 C:\wamp64\www\proyectoLibreria\system\View\View.php(235): include('C:\\wamp64\\www\\p...')
#2 C:\wamp64\www\proyectoLibreria\system\Common.php(175): CodeIgniter\View\View->render('includes/header', Array, NULL)
#3 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(37): view('includes/header', Array)
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->index()
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 11:32:00 --> Undefined index: foto
#0 C:\wamp64\www\proyectoLibreria\app\Views\includes\header.php(22): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined index...', 'C:\\wamp64\\www\\p...', 22, Array)
#1 C:\wamp64\www\proyectoLibreria\system\View\View.php(235): include('C:\\wamp64\\www\\p...')
#2 C:\wamp64\www\proyectoLibreria\system\Common.php(175): CodeIgniter\View\View->render('includes/header', Array, NULL)
#3 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(37): view('includes/header', Array)
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->index()
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 11:32:28 --> syntax error, unexpected '?>'
#0 C:\wamp64\www\proyectoLibreria\system\Common.php(175): CodeIgniter\View\View->render('includes/header', Array, NULL)
#1 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(37): view('includes/header', Array)
#2 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->index()
#3 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2020-05-30 11:33:19 --> syntax error, unexpected '?>'
#0 C:\wamp64\www\proyectoLibreria\system\Common.php(175): CodeIgniter\View\View->render('includes/header', Array, NULL)
#1 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(37): view('includes/header', Array)
#2 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->index()
#3 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2020-05-30 11:33:21 --> syntax error, unexpected '?>'
#0 C:\wamp64\www\proyectoLibreria\system\Common.php(175): CodeIgniter\View\View->render('includes/header', Array, NULL)
#1 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(37): view('includes/header', Array)
#2 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->index()
#3 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#5 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#6 {main}
CRITICAL - 2020-05-30 11:38:02 --> session_regenerate_id(): Cannot regenerate session id - session is not active
#0 [internal function]: CodeIgniter\Debug\Exceptions->errorHandler(2, 'session_regener...', 'C:\\wamp64\\www\\p...', 282, Array)
#1 C:\wamp64\www\proyectoLibreria\system\Session\Session.php(282): session_regenerate_id(true)
#2 C:\wamp64\www\proyectoLibreria\app\Controllers\UserController.php(27): CodeIgniter\Session\Session->stop()
#3 C:\wamp64\www\proyectoLibreria\app\Controllers\UserController.php(13): App\Controllers\UserController->login()
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\UserController->index()
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UserController))
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 11:38:47 --> session_regenerate_id(): Cannot regenerate session id - session is not active
#0 [internal function]: CodeIgniter\Debug\Exceptions->errorHandler(2, 'session_regener...', 'C:\\wamp64\\www\\p...', 282, Array)
#1 C:\wamp64\www\proyectoLibreria\system\Session\Session.php(282): session_regenerate_id(true)
#2 C:\wamp64\www\proyectoLibreria\app\Controllers\UserController.php(27): CodeIgniter\Session\Session->stop()
#3 C:\wamp64\www\proyectoLibreria\app\Controllers\UserController.php(13): App\Controllers\UserController->login()
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\UserController->index()
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\UserController))
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 11:41:14 --> Unknown column 'id_book' in 'group statement'
#0 C:\wamp64\www\proyectoLibreria\system\Database\MySQLi\Connection.php(329): mysqli->query('SELECT *\nFROM `...')
#1 C:\wamp64\www\proyectoLibreria\system\Database\BaseConnection.php(709): CodeIgniter\Database\MySQLi\Connection->execute('SELECT *\nFROM `...')
#2 C:\wamp64\www\proyectoLibreria\system\Database\BaseConnection.php(637): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT *\nFROM `...')
#3 C:\wamp64\www\proyectoLibreria\system\Database\BaseBuilder.php(1476): CodeIgniter\Database\BaseConnection->query('SELECT *\nFROM `...', Array, false)
#4 C:\wamp64\www\proyectoLibreria\system\Model.php(434): CodeIgniter\Database\BaseBuilder->get()
#5 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(94): CodeIgniter\Model->findAll(10)
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->mostRead()
#7 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#8 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#9 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#10 {main}
CRITICAL - 2020-05-30 11:53:25 --> Not unique table/alias: 'books'
#0 C:\wamp64\www\proyectoLibreria\system\Database\MySQLi\Connection.php(329): mysqli->query('SELECT count(id...')
#1 C:\wamp64\www\proyectoLibreria\system\Database\BaseConnection.php(709): CodeIgniter\Database\MySQLi\Connection->execute('SELECT count(id...')
#2 C:\wamp64\www\proyectoLibreria\system\Database\BaseConnection.php(637): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT count(id...')
#3 C:\wamp64\www\proyectoLibreria\system\Database\BaseBuilder.php(1476): CodeIgniter\Database\BaseConnection->query('SELECT count(id...', Array, false)
#4 C:\wamp64\www\proyectoLibreria\system\Model.php(434): CodeIgniter\Database\BaseBuilder->get()
#5 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(95): CodeIgniter\Model->findAll(10)
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->mostRead()
#7 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#8 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#9 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#10 {main}
CRITICAL - 2020-05-30 11:53:51 --> Undefined property: App\Controllers\BookController::$nowreading
#0 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(91): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined prope...', 'C:\\wamp64\\www\\p...', 91, Array)
#1 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->mostRead()
#2 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#3 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2020-05-30 11:54:45 --> Unknown column 'favourite.id_book' in 'on clause'
#0 C:\wamp64\www\proyectoLibreria\system\Database\MySQLi\Connection.php(329): mysqli->query('SELECT count(id...')
#1 C:\wamp64\www\proyectoLibreria\system\Database\BaseConnection.php(709): CodeIgniter\Database\MySQLi\Connection->execute('SELECT count(id...')
#2 C:\wamp64\www\proyectoLibreria\system\Database\BaseConnection.php(637): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT count(id...')
#3 C:\wamp64\www\proyectoLibreria\system\Database\BaseBuilder.php(1476): CodeIgniter\Database\BaseConnection->query('SELECT count(id...', Array, false)
#4 C:\wamp64\www\proyectoLibreria\system\Model.php(434): CodeIgniter\Database\BaseBuilder->get()
#5 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(95): CodeIgniter\Model->findAll(10)
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->mostRead()
#7 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#8 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#9 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#10 {main}
CRITICAL - 2020-05-30 11:55:16 --> Undefined variable: books
#0 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(96): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined varia...', 'C:\\wamp64\\www\\p...', 96, Array)
#1 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->mostRead()
#2 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#3 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2020-05-30 11:55:31 --> Undefined variable: users
#0 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(98): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined varia...', 'C:\\wamp64\\www\\p...', 98, Array)
#1 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->mostRead()
#2 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#3 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2020-05-30 11:55:55 --> Undefined index: id
#0 C:\wamp64\www\proyectoLibreria\app\Views\pages\browse.php(9): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined index...', 'C:\\wamp64\\www\\p...', 9, Array)
#1 C:\wamp64\www\proyectoLibreria\system\View\View.php(235): include('C:\\wamp64\\www\\p...')
#2 C:\wamp64\www\proyectoLibreria\system\Common.php(175): CodeIgniter\View\View->render('pages/browse', Array, NULL)
#3 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(100): view('pages/browse', Array)
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->mostRead()
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 11:56:40 --> Undefined index: id
#0 C:\wamp64\www\proyectoLibreria\app\Views\pages\browse.php(9): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined index...', 'C:\\wamp64\\www\\p...', 9, Array)
#1 C:\wamp64\www\proyectoLibreria\system\View\View.php(235): include('C:\\wamp64\\www\\p...')
#2 C:\wamp64\www\proyectoLibreria\system\Common.php(175): CodeIgniter\View\View->render('pages/browse', Array, NULL)
#3 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(100): view('pages/browse', Array)
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->mostRead()
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 11:57:18 --> Undefined index: id
#0 C:\wamp64\www\proyectoLibreria\app\Views\pages\browse.php(9): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined index...', 'C:\\wamp64\\www\\p...', 9, Array)
#1 C:\wamp64\www\proyectoLibreria\system\View\View.php(235): include('C:\\wamp64\\www\\p...')
#2 C:\wamp64\www\proyectoLibreria\system\Common.php(175): CodeIgniter\View\View->render('pages/browse', Array, NULL)
#3 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(100): view('pages/browse', Array)
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->mostRead()
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 12:31:53 --> Undefined variable: nowreading
#0 C:\wamp64\www\proyectoLibreria\app\Views\pages\browse.php(16): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined varia...', 'C:\\wamp64\\www\\p...', 16, Array)
#1 C:\wamp64\www\proyectoLibreria\system\View\View.php(235): include('C:\\wamp64\\www\\p...')
#2 C:\wamp64\www\proyectoLibreria\system\Common.php(175): CodeIgniter\View\View->render('pages/browse', Array, NULL)
#3 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(37): view('pages/browse', Array)
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->index()
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
CRITICAL - 2020-05-30 12:54:37 --> Undefined variable: idBook
#0 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(38): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined varia...', 'C:\\wamp64\\www\\p...', 38, Array)
#1 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->index()
#2 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#3 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#5 {main}
CRITICAL - 2020-05-30 12:55:21 --> Undefined variable: nowreading
#0 C:\wamp64\www\proyectoLibreria\app\Views\pages\browse.php(16): CodeIgniter\Debug\Exceptions->errorHandler(8, 'Undefined varia...', 'C:\\wamp64\\www\\p...', 16, Array)
#1 C:\wamp64\www\proyectoLibreria\system\View\View.php(235): include('C:\\wamp64\\www\\p...')
#2 C:\wamp64\www\proyectoLibreria\system\Common.php(175): CodeIgniter\View\View->render('pages/browse', Array, NULL)
#3 C:\wamp64\www\proyectoLibreria\app\Controllers\BookController.php(37): view('pages/browse', Array)
#4 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(838): App\Controllers\BookController->index()
#5 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(335): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\BookController))
#6 C:\wamp64\www\proyectoLibreria\system\CodeIgniter.php(245): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\wamp64\www\proyectoLibreria\index.php(45): CodeIgniter\CodeIgniter->run()
#8 {main}
