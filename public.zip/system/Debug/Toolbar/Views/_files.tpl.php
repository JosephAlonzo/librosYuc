<table>
    <tbody>
    {userFiles}
        <tr>
            <td>{name}</td>
            <td>{path}</td>
        </tr>
    {/userFiles}
    {coreFiles}
        <tr class="muted">
            <td class="debug-bar-width20e">{name}</td>
            <td>{path}</td>
        </tr>
    {/coreFiles}
    </tbody>
</table>
